#' Useful function to increment by one
#' 
#' @param x the numeric variable to be incremented
#' @export
drattest <- function(x) {
  print("This is the drat test!")
  x + 1
}